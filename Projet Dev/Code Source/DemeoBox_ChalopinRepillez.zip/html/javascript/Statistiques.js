$('#Accueil').click(function(){
   window.location.href='index.html';
})