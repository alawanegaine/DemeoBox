$('#Programmation').click(function(){
   window.location.href='Programmation.html';
})

$('#CmdMnl').click(function(){
   window.location.href='CommandesManuelles.html';
})

$('#Stat').click(function(){
   window.location.href='Statistiques.html';
})