<?php
	session_start();

	echo "Value : ".$_SESSION['isInManualMode'];
?>
